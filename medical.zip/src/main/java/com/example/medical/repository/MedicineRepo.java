package com.example.medical.repository;

import com.example.medical.model.Medicine;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MedicineRepo extends JpaRepository<Medicine, Integer> {
    //Custom query
    @Query(value = "select * from medicine m where m.name like %:keyword%", nativeQuery = true)
    List<Medicine> findByKeyword(@Param("keyword") String keyword);
}
