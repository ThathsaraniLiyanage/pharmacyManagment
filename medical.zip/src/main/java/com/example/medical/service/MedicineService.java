package com.example.medical.service;

import com.example.medical.model.Medicine;

import java.util.List;

public interface MedicineService {
    List<Medicine> getAllMedicine();
    void saveMedicine(Medicine medicine);
    Medicine getMedicineById(Integer id);
    void deleteMedicineById(Integer id);
    List<Medicine> searchMedicine(String keyword);
}
