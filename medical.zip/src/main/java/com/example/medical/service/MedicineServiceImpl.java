package com.example.medical.service;

import com.example.medical.model.Medicine;
import com.example.medical.repository.MedicineRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
public class MedicineServiceImpl implements MedicineService{
    @Autowired
    private MedicineRepo medicineRepo;

    @Override
    public List <Medicine> getAllMedicine(){
        return this.medicineRepo.findAll();
    }

    @Override
    public void saveMedicine(Medicine medicine) {
        this.medicineRepo.save(medicine);
    }

    @Override
    public Medicine getMedicineById(Integer id){
        Optional <Medicine> optional = medicineRepo.findById(id);
        Medicine medicine = null;
        if (optional.isPresent()){
            medicine = optional.get();

        } else {
            throw new RuntimeException("Medicine not found for id :: "+ id);
        }
        return medicine;
    }

    @Override
    public void deleteMedicineById(Integer id) {
        this.medicineRepo.deleteAllById(Collections.singleton(id));
    }

    @Override
    public List<Medicine> searchMedicine(String keyword) {
        return medicineRepo.findByKeyword(keyword);
    }
}
