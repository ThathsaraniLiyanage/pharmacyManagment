package com.example.medical.controller;

import com.example.medical.model.Medicine;
import com.example.medical.service.MedicineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class MedicineController {
    @Autowired
    private MedicineService medicineService;

//    @GetMapping("/")
//    public String viewHomePage(Model model){
//        model.addAttribute("listMedicine", medicineService.getAllMedicine());
//        return "index";
//    }
    @RequestMapping(path={"/","/searchMedicine"})
    public String searchMedicine(Medicine medicine, Model model, String keyword){
        if(keyword!=null){
            List<Medicine> list = medicineService.searchMedicine(keyword);
            model.addAttribute("listMedicine", list);
        }else{
            List<Medicine> list = medicineService.getAllMedicine();
            model.addAttribute("listMedicine", list);}
        return "index";
        }

    @GetMapping("/newMedicineFrom")
    public String newMedicineFrom(Model model){
        Medicine medicine = new Medicine();
        model.addAttribute("medicine", medicine);
        return "new_Medicine";
    }

    @PostMapping("/saveMedicine")
    public String SaveMedicine(@ModelAttribute("medicine") Medicine medicine){
        medicineService.saveMedicine(medicine);
        return "redirect:/";
    }

    @GetMapping("/updateMedicineFrom/{id}")
    public String updateMedicineForm(@PathVariable(value = "id") Integer id, Model model){
        Medicine medicine = medicineService.getMedicineById(id);

        model.addAttribute("medicine", medicine);
        return "update_medicine";
    }

    @GetMapping("/deleteMedicine/{id}")
    public String deleteMedicine(@PathVariable(value = "id")Integer id){
        this.medicineService.deleteMedicineById(id);
        return "redirect:/";
    }
}
